/*============================================
# Filename: SamSelect.cpp
# Ver 1.0 2016-08-26
# Copyright (C) 2016 weidingbang (weidingbang1992@163.com)
#
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 or later of the License.
#
# Description: 
=============================================*/
#include"SamSelect.h"
#include <stack>
#include <fstream>
#include <time.h>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>
#include <sstream>

#define CLUNUM 5000
#define SAMSELMINNUM 10

SamSelect::SamSelect()
{

}

int SamSelect::get_charlen(const char* a)
{
	int i = 0;
	while (a[i] != '\0')
	{
		i++;
	}
	return i;

}

void SamSelect::Initial()
{
	m_fileName = m_mc.inputFile.c_str();
	m_l = m_mc.l;
	m_d = m_mc.d;
	m_q = m_mc.q;
	m_T = m_mc.T;

	for (int i = 0; i < 25; ++i)
	{
		vector<double> temp;
		for (int j = 0; j < 10; ++j)
		{
			temp.push_back(0);
		}
		m_hamprobability.push_back(temp);
	}
	m_hamprobability[9][2] = 0.0013;
	m_hamprobability[10][2] = 0.0004;
	m_hamprobability[11][3] = 0.00118;
	m_hamprobability[13][4] = 0.00099;
	m_hamprobability[15][5] = 0.00082;
	m_hamprobability[17][6] = 0.0002;
	m_hamprobability[19][7] = 0.0004;
	m_hamprobability[21][8] = 0.0003;

	for (int i = 0; i < 25; ++i)
	{
		vector<float> temp_float;
		for (int j = 0; j < 10; ++j)
		{
			temp_float.push_back(0);
		}
		m_average_lmerPair_dis.push_back(temp_float);
	}
	m_average_lmerPair_dis[9][2] = 2.6;
	m_average_lmerPair_dis[11][3] = 3.8;
	m_average_lmerPair_dis[13][4] = 5.0;
	m_average_lmerPair_dis[15][5] = 6.1;
	m_average_lmerPair_dis[17][6] = 7.3;
	m_average_lmerPair_dis[19][7] = 8.4;
	m_average_lmerPair_dis[21][8] = 9.6;
}

void SamSelect::preprocessing()
{
	
}

bool CompOcc(const subStrContext & p1, const subStrContext & p2)
{
	return p1.occ > p2.occ;
}

void SamSelect::SeqFiltering(MotifConfig mc)
{
	//initial
	Initial();

	m_mc = mc;
	Initial();
	clock_t be = clock();
	FM *fm = NULL;
	fm=new FM(m_fileName);

	string data_fileName(m_fileName);
	ifstream inFile(m_fileName);
	if (!inFile)//open failed
		cout<<" file1 open failed"<<endl;
	string s;
	int count = 0;
	while (!inFile.eof())
	{
		count++;
		getline(inFile, s);
		if(count % 2 == 1)
		{
			continue;
		}
		filestring.push_back(s);
	}
	filestring[filestring.size() - 1] += " ";

	m_t = filestring.size();
	m_n = filestring[0].size() - 1;

	int index_table_length = 12;
	alllmer_1mismatch_count = fm->CountingAllOneMisLmer(index_table_length);

	int occ = OccRx() + OccMx() + 2;
	GenSubString(occ);
	while (vssc.size() > CLUNUM)
	{
		vssc.clear();
		occ = occ + 2;
		GenSubString(occ);
	}

	//spilt substring
	SplittingSubString();
	
	//cluster
	vector<int> temp_center;
	AP_Cluster AP(vssc, 0.00001, m_l, m_d);
	temp_result = AP.CutClusterSet(temp_center);

	AP_Result temp;
	for (int i = 0; i < temp_result.size(); ++i)
	{
		for (int j = 0; j < temp_result[i].size(); ++j)
		{
			temp.sub_result.push_back(temp_result[i][j]);
		}
		temp.center = temp_center[i];
		ap_result.push_back(temp);
		temp.sub_result.clear();
	}

	//Sort the number of elements in the cluster
	AP_Result p;
	for (int i = 0; i < ap_result.size() - 1; i++)
	{
		for (int j = 0; j < ap_result.size() - 1 - i; j++)
		{
			if (ap_result[j].sub_result.size() < ap_result[j + 1].sub_result.size())
			{
				p = ap_result[j];
				ap_result[j] = ap_result[j + 1];
				ap_result[j + 1] = p;
			}
		}
	}
	
	//combining after AP
	MergingAfterAP();

	//rank
	Rank();

	//filter ap result
	FilteringAPResult();

	//output samselct sequences
	OutputSamSeq();
	
	clock_t en = clock();
	cout<<"build time is "<<(en-be)/CLOCKS_PER_SEC<<"s"<<endl;
}


void SamSelect::OutputSamSeq()
{
	for (int i = 0; i < ap_result.size(); ++i)
	{
		string outfilename;
		stringstream ss;
		string index_str;
		ss<<i;
		ss>>index_str;

		string fileName(m_fileName);
		outfilename = fileName + "_"+ index_str;

		ofstream outFile(outfilename.c_str());

		if (ap_result[i].sub_result.size() > m_T)
		{
			for (int j = 0; j < m_T; ++j)
			{
				outFile<<">Sequence"<<endl;
				outFile<<filestring[ap_result[i].sub_result[j].row]<<endl;
			}
		}
		else
		{
			for (int j = 0; j < ap_result[i].sub_result.size(); ++j)
			{
				outFile<<">Sequence"<<endl;
				outFile<<filestring[ap_result[i].sub_result[j].row]<<endl;
			}
		}
	}
}

void SamSelect::FilteringAPResult()
{
	//for each cluster, remain substrings
	for (int i = 0; i < ap_result.size(); ++i)
	{
		for (int j = 0; j < ap_result[i].sub_result.size(); ++j)
		{
			int iter_count = -1;
			for(vector<subStrContext>::iterator iter = ap_result[i].sub_result.begin(); iter!=ap_result[i].sub_result.end(); )
			{
				iter_count++;
				if(iter_count >= m_T)
					iter = ap_result[i].sub_result.erase(iter);
				else
					iter++;
			}
		}
	}

	//rule 1
	for (int i = 0; i < ap_result.size(); ++i)
	{
		for (int j = 0; j < ap_result[i].sub_result.size(); ++j)
		{
			if (j == m_T)
			{
				break;
			}
			int ham = HamDisNum(vssc[ap_result[i].center].subStr, ap_result[i].sub_result[j].subStr);

			if (ham >= (int) (3 / 2.0 * m_d))
			{
				int iter_count = -1;
				for(vector<subStrContext>::iterator iter = ap_result[i].sub_result.begin(); iter!=ap_result[i].sub_result.end(); )
				{
					iter_count++;
					if(iter_count == j)
						iter = ap_result[i].sub_result.erase(iter);
					else
						iter++;
				}
				j--;
			}
		}
	}

	//rule 2
	for (int i = 0; i < ap_result.size(); ++i)
	{
		for (int j = 0; (j < ap_result[i].sub_result.size() - 1); ++j)
		{
			if (j == m_T - 1)
			{
				break;
			}
			for (int k = j + 1; (k < ap_result[i].sub_result.size()); ++k)
			{
				int ham = HamDisNum(ap_result[i].sub_result[j].subStr, ap_result[i].sub_result[k].subStr);
				if (ham > 2 * m_d)
				{
					int iter_count = -1;
					for(vector<subStrContext>::iterator iter = ap_result[i].sub_result.begin(); iter!=ap_result[i].sub_result.end(); )
					{
						iter_count++;
						if(iter_count == k)
							iter = ap_result[i].sub_result.erase(iter);
						else
							iter++;
					}
					k--;
				}
			}
		}
	}

	
	
	//rule 3
	for (int i = 0; i < ap_result.size(); ++i)
	{
		if (ap_result[i].sub_result.size() < SAMSELMINNUM)
		{
			int iter_count = -1;
			for(vector<AP_Result>::iterator iter = ap_result.begin(); iter!=ap_result.end(); )
			{
				iter_count++;
				if(iter_count == i)
					iter = ap_result.erase(iter);
				else
					iter++;
			}
			i--;
		}
		
	}

	//Calculate the sum of the minimum Hamming distances of any two substrings in the cluster
	vector<int> v_hamsum;
	vector<float> v_hamave;
	for (int i = 0; i < ap_result.size(); ++i)
	{
		int hamsum = 0;
		float hamave;
		for (int j = 0; (j < ap_result[i].sub_result.size() - 1); ++j)
		{
			for (int k = j + 1; (k < ap_result[i].sub_result.size()); ++k)
			{
				int ham = HamDisNum(ap_result[i].sub_result[j].subStr, ap_result[i].sub_result[k].subStr);
				hamsum += ham;
			}
		}
		v_hamsum.push_back(hamsum);

		//calculate average
		hamave = hamsum / (ap_result[i].sub_result.size() * (ap_result[i].sub_result.size() - 1) * 0.5);
		v_hamave.push_back(hamave);
	}

	for (int i = 0; i < ap_result.size(); ++i)
	{
		while(v_hamave[i] > m_average_lmerPair_dis[m_l][m_d])
		{
			int iter_count = -1;
			int delete_count = ap_result[i].sub_result.size() - 10;
			for(vector<subStrContext>::iterator iter = ap_result[i].sub_result.begin(); iter!=ap_result[i].sub_result.end(); )
			{
				iter_count++;
				if(iter_count >= delete_count)
					iter = ap_result[i].sub_result.erase(iter);
				else
					iter++;
			}

			int hamsum = 0;
			float hamave;
			for (int j = 0; (j < ap_result[i].sub_result.size() - 1); ++j)
			{
				for (int k = j + 1; (k < ap_result[i].sub_result.size()); ++k)
				{
					int ham = HamDisNum(ap_result[i].sub_result[j].subStr, ap_result[i].sub_result[k].subStr);
					hamsum += ham;
				}
			}
			v_hamave[i] = hamsum / (ap_result[i].sub_result.size() * (ap_result[i].sub_result.size() - 1) * 0.5);
		}
	}
}

vector<int> SortIndex(vector<int> a)
{
	vector<int> p;
	int temp;
	for(int i = 0; i < a.size(); i++)
		p.push_back(i);

	for (int i = 0; i < a.size() - 1; i++)
		for (int j = 0; j < a.size() - 1 - i; j++)
			if(a[j] < a[j + 1])
			{
				temp = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp;

				temp = p[j];
				p[j] = p[j + 1];
				p[j + 1] = temp;
			}

	return p;
}

void SamSelect::SplittingSubString()
{
	vector<vector<int> > position;
	for (int i = 0; i < vssc.size(); ++i)
	{
		vector<int> temp;
		for (int j = 0; j < vssc[i].subStr.size() - m_l + 1; ++j)
		{
			temp.push_back(0);
		}
		position.push_back(temp);
	}

	for (int i = 0; i < vssc.size() - 1; ++i)
	{
		for (int j = i + 1; j < vssc.size(); ++j)
		{
			int a, b;
			int ham = HamDisNum(vssc[i].subStr, vssc[j].subStr, a, b);
			if (ham <= m_d)
			{
				position[i][a] = position[i][a] + 1;
				position[j][b] = position[j][b] + 1;
			}
		}
	}

	

    //Split substring
	vector<subStrContext> qg_vssc;
	for(int i = 0; i < vssc.size(); i++)
	{
		vector<int> sortArray;
		sortArray = SortIndex(position[i]);
		int maxIndex = sortArray[0];



		int l_len, r_len, total_num_mer;
		total_num_mer = sortArray.size();
		l_len = maxIndex;
		r_len = total_num_mer - (maxIndex + 1);

        int l_id, r_id;

		if (l_len >= 3)
		{
			l_id = maxIndex - 3;
		}
		else
		{
			l_id = 0;
		}

		if (r_len >= 3)
		{
			r_id = maxIndex + m_l - 1 + 3;
		}
		else
		{
			r_id = total_num_mer + m_l - 1;
		}

        subStrContext ssc = vssc[i]; 
		ssc.subStr = vssc[i].subStr.substr(l_id, r_id - l_id + 1);

		qg_vssc.push_back(ssc);

		// handle left
		if (l_len >= m_l) // need to form a new substr
		{
         		vector<int> sortArray_temp;
         		vector<int> position_temp;
         		for (int ii = 0; ii < l_len - m_l + 1; ii++)
         		{
         			position_temp.push_back(position[i][ii]);
         		}
				sortArray_temp = SortIndex(position_temp);
				int maxIndex_temp = sortArray_temp[0];

				if (maxIndex_temp >= 2)
				{
					l_id = maxIndex_temp - 2;
				}
				else
				{
					l_id = 0;
				}

				r_id = maxIndex_temp + m_l + 2;

			subStrContext ssc = vssc[i]; 
			ssc.subStr = vssc[i].subStr.substr(l_id, r_id - l_id + 1);
			qg_vssc.push_back(ssc);
		}

	    // handle right
	    if (r_len >= m_l) // need to form a new substr
		{
				vector<int> sortArray_temp;
         		vector<int> position_temp;
         		for (int ii = 0; ii < r_len - m_l + 1; ii++)
         		{
         			position_temp.push_back(position[i][maxIndex + m_l + ii]);
         		}
				sortArray_temp = SortIndex(position_temp);
				int maxIndex_temp = sortArray_temp[0];

                l_id = maxIndex + m_l + maxIndex_temp - 3;
				
				if  ((r_len - 1) - (maxIndex_temp + m_l) >= 2)
				{
					r_id = maxIndex + m_l + maxIndex_temp + m_l + 2;
				}
				else
				{
					r_id = maxIndex + m_l - 1 + r_len;
				}
			
				subStrContext ssc = vssc[i]; 
				ssc.subStr = vssc[i].subStr.substr(l_id, r_id - l_id + 1);
				qg_vssc.push_back(ssc);
		}
		
	}

	vssc.clear();
	vssc = qg_vssc;
}



void SamSelect::MergingAfterAP()
{
	for (int i = 0; i < ap_result.size(); ++i)
	{
		int cluster_flag = 0;
		string center_str = vssc[ap_result[i].center].subStr;
		while(cluster_flag == 0)
		{
			vector<int> temp_rate;
			for (int j = i + 1; j < ap_result.size(); ++j)
			{
				int count = HamDisNum(center_str, ap_result[j].sub_result);
				if (count >= (int)(0.2 * ap_result[j].sub_result.size()))
				{
					temp_rate.push_back(1);
				}
				else
					temp_rate.push_back(0);
			}

			int combine_flag = 0;
			for (int i = 0; i < temp_rate.size(); ++i)
			{
				if (temp_rate[i] == 1)
				{
					combine_flag = 1;
				}
			}

			int del = 0;
			if (combine_flag == 0)
			{
				cluster_flag = 1;
				break;
			}
			else
			{
				for (int j = 0; j < temp_rate.size(); ++j)
				{
					if (temp_rate[j] == 1)
					{
						for (int k = 0; k < ap_result[i + j -del + 1].sub_result.size(); ++k)
						{
							ap_result[i].sub_result.push_back(ap_result[i + j -del + 1].sub_result[k]);
						}

						int count = -1;
						for(vector<AP_Result>::iterator iter=ap_result.begin(); iter!=ap_result.end(); )
						{
							count++;
     						if(count == i + j - del + 1)
     						{
          						iter = ap_result.erase(iter);
          						del++;
     						}
      						else
            					iter ++ ;
						}
					}
					
				}
			}
			if (ap_result.size() == 1)
			{
				cluster_flag = 1;
			}


		}
	}
}

void SamSelect::Rank()
{
	for (int i = 0; i < ap_result.size(); ++i)
	{
		string center_str = vssc[ap_result[i].center].subStr;
		for (int j = 0; j < ap_result[i].sub_result.size(); ++j)
		{
			ap_result[i].sub_result[j].ham_to_center = HamDisNum(center_str, ap_result[i].sub_result[j].subStr);
		}

		subStrContext p;
		for (int j = 0; j < ap_result[i].sub_result.size() - 1; j++)
		{
			for (int k = 0; k < ap_result[i].sub_result.size() - 1 - j; k++)
			{
				if (ap_result[i].sub_result[k].ham_to_center > ap_result[i].sub_result[k + 1].ham_to_center)
				{
					p = ap_result[i].sub_result[k];
					ap_result[i].sub_result[k] = ap_result[i].sub_result[k + 1];
					ap_result[i].sub_result[k + 1] = p;
				}
			}
		}
	}
}

int SamSelect::HamDisNum(string str_a, string str_b, int &a, int &b)
{
	int minhamdis = m_l + 1;
	for (int i = 0; i < str_a.size() - m_l + 1; ++i)
	{
		for (int j = 0; j < str_b.size() - m_l + 1; ++j)
		{
			int hamdis = 0;
			for (int l = 0; l < m_l; ++l)
			{
				if (str_a[i + l] != str_b[j + l])
				{
					hamdis++;
				}
			}
			if (hamdis < minhamdis)
			{
				minhamdis = hamdis;
				a = i;
				b = j;
			}
		}
	}
	return minhamdis;
}


int SamSelect::HamDisNum(string str_a, string str_b)
{
	int minhamdis = m_l + 1;
	for (int i = 0; i < str_a.size() - m_l + 1; ++i)
	{
		for (int j = 0; j < str_b.size() - m_l + 1; ++j)
		{
			int hamdis = 0;
			for (int l = 0; l < m_l; ++l)
			{
				if (str_a[i + l] != str_b[j + l])
				{
					hamdis++;
				}
			}
			if (hamdis < minhamdis)
			{
				minhamdis = hamdis;
			}
		}
	}
	return minhamdis;
}

int SamSelect::HamDisNum(string str, vector<subStrContext> vs)
{
	int count = 0;
	for (int i = 0; i < vs.size(); ++i)
	{
		int minhamdis = m_l + 1;
		for (int m = 0; m < str.size() - m_l + 1; ++m)
		{
			for (int n = 0; n < vs[i].subStr.size() - m_l + 1; ++n)
			{
				int hamdis = 0;
				for (int l = 0; l < m_l; ++l)
				{
					if (str[m + l] != vs[i].subStr[n + l])
					{
						hamdis++;
					}
				}
				if (hamdis < minhamdis)
				{
					minhamdis = hamdis;
				}
			}
		}

		if (minhamdis <= m_d)
		{
			count++;
		}
	}
	return count;
}

int SamSelect::HamDisNum(vector<subStrContext> a, vector<subStrContext> b)
{
	int count = 0;
	for (int i = 0; i < a.size(); ++i)
	{
		for (int j = 0; j < b.size(); ++j)
		{
			int minhamdis = m_l + 1;
			for (int m = 0; m < a[i].subStr.size() - m_l + 1; ++m)
			{
				for (int n = 0; n < b[j].subStr.size() - m_l + 1; ++n)
				{
					int hamdis = 0;
					for (int l = 0; l < m_l; ++l)
					{
						if (a[i].subStr[m + l] != b[j].subStr[n + l])
						{
							hamdis++;
						}
					}
					if (hamdis < minhamdis)
					{
						minhamdis = hamdis;
					}
				}
			}

			if (minhamdis <= m_d)
			{
				count++;
			}
		}
	}
	return count;
}

void SamSelect::CorrentnessAfterAP()
{
	vector<int> cluster_after_MotIns_line;
	vector<string> string_true_MotIns_line;
	vector<int> int_true_MotIns_line;
	
	string motif_fileName = "";
	string data_fileName(m_fileName);
	string temp_fileName = "RanGenDataBig/motif/motif";

	for (int i = 23; i < data_fileName.size(); ++i)
	{
		motif_fileName += data_fileName[i];
	}
	motif_fileName = temp_fileName + motif_fileName;

	ifstream inFile_motif(motif_fileName.c_str());
	if (!inFile_motif)//open failed
		cout<<"file open failed"<<endl;

	string motif_s;
	int motif_count = 0;
	while (!inFile_motif.eof())
	{
		motif_count++;
		getline(inFile_motif, motif_s);

		if (motif_count > 4)
		{
			if(motif_count % 2 == 1)
			{
				string_true_MotIns_line.push_back(motif_s);
			}
		}
	}

	for (int i = 0; i < string_true_MotIns_line.size(); ++i)
	{
		int_true_MotIns_line.push_back(atoi(string_true_MotIns_line[i].c_str()));
	}


	for (int i = 0; i < ap_result.size(); ++i)
	{
		int temp = -1;
		for (int m = 0; m < m_t; ++m)
		{
			cluster_after_MotIns_line.push_back(temp);
		}
		if (ap_result[i].sub_result.size() > m_T)
		{
			int real_top = 0;

			for (int j = 0; j < ap_result[i].sub_result.size(); ++j)
			{
				if (cluster_after_MotIns_line[ap_result[i].sub_result[j].row] == -1)
				{
					cluster_after_MotIns_line[ap_result[i].sub_result[j].row] = 1;
					real_top++;
				}
				else
				{
					int count = -1;
					for(vector<subStrContext>::iterator iter = ap_result[i].sub_result.begin(); iter!=ap_result[i].sub_result.end(); )
					{
						count++;
     					if(count == j)
          					iter = ap_result[i].sub_result.erase(iter);
      					else
            				iter++;
					}
				}
				
				if (real_top == m_T)
				{
					break;
				}
			}
		}
		else
		{
			for (int j = 0; j < ap_result[i].sub_result.size(); ++j)
			{
				cluster_after_MotIns_line[ap_result[i].sub_result[j].row] = 1;
			}


			for (int j = 0; j < ap_result[i].sub_result.size(); ++j)
			{
				if (cluster_after_MotIns_line[ap_result[i].sub_result[j].row] == -1)
				{
					cluster_after_MotIns_line[ap_result[i].sub_result[j].row] = 1;
				}
				else
				{
					int count = -1;
					for(vector<subStrContext>::iterator iter = ap_result[i].sub_result.begin(); iter!=ap_result[i].sub_result.end(); )
					{
						count++;
     					if(count == j)
          					iter = ap_result[i].sub_result.erase(iter);
      					else
            				iter++;
					}
				}
			}

		}

		int true_instance_num = 0, corrent_num = 0, wrong_num = 0;
		for (int j = 0; j < cluster_after_MotIns_line.size(); ++j)
		{
			if ((cluster_after_MotIns_line[j] >= 0) && (int_true_MotIns_line[j] >= 0))
			{
				corrent_num++;
			}
			if ((cluster_after_MotIns_line[j] >= 0) && (int_true_MotIns_line[j] < 0))
			{
				wrong_num++;
			}
			if (int_true_MotIns_line[j] >= 0)
			{
				true_instance_num++;
			}
		}

		float corrent_rate = (float)corrent_num / (corrent_num + wrong_num);
		cout<<"file: "<<m_fileName<<endl;
		cout<<"result: "<<i<<endl;
		cout<<"High frequency substring number after AP: "<<ap_result[i].sub_result.size()<<endl;
		cout<<"total sequence: "<<m_t<<endl;
		cout<<"true motif instance num "<<true_instance_num<<endl;
		cout<<"counting corrent num: "<<corrent_num<<endl;
		cout<<"counting wrong num "<<wrong_num<<endl;
		cout<<"rate "<<corrent_rate<<endl;

		cluster_after_MotIns_line.clear();
	}
}

void SamSelect::CorrentnessBeforeAP()
{
	vector<int> cluster_before_MotIns_line;
	vector<string> string_true_MotIns_line;
	vector<int> int_true_MotIns_line;
	int temp = -1;
	for (int i = 0; i < m_t; ++i)
	{
		cluster_before_MotIns_line.push_back(temp);
	}
	for (int i = 0; i < vssc.size(); ++i)
	{
		cluster_before_MotIns_line[vssc[i].row] = 1;
	}
	
	string motif_fileName = "";
	string data_fileName(m_fileName);
	string temp_fileName = "RanGenDataBig/motif/motif";

	for (int i = 23; i < data_fileName.size(); ++i)
	{
		motif_fileName += data_fileName[i];
	}
	motif_fileName = temp_fileName + motif_fileName;

	ifstream inFile_motif(motif_fileName.c_str());
	if (!inFile_motif)//open failed
		cout<<"file open failed"<<endl;

	string motif_s;
	int motif_count = 0;
	while (!inFile_motif.eof())
	{
		motif_count++;
		getline(inFile_motif, motif_s);

		if (motif_count > 4)
		{
			if(motif_count % 2 == 1)
			{
				string_true_MotIns_line.push_back(motif_s);
			}
		}
		
	}

	for (int i = 0; i < string_true_MotIns_line.size(); ++i)
	{
		int_true_MotIns_line.push_back(atoi(string_true_MotIns_line[i].c_str()));
	}

	int true_instance_num = 0, corrent_num = 0, wrong_num = 0;
	for (int i = 0; i < cluster_before_MotIns_line.size(); ++i)
	{
		if ((cluster_before_MotIns_line[i] >= 0) && (int_true_MotIns_line[i] >= 0))
		{
			corrent_num++;
		}
		if ((cluster_before_MotIns_line[i] >= 0) && (int_true_MotIns_line[i] < 0))
		{
			wrong_num++;
		}
		if (int_true_MotIns_line[i] >= 0)
		{
			true_instance_num++;
		}
	}

	float corrent_rate = (float)corrent_num / (corrent_num + wrong_num);
	cout<<"file: "<<m_fileName<<endl;
	cout<<"High frequency substring number before AP: "<<vssc.size()<<endl;
	cout<<"total sequence: "<<m_t<<endl;
	cout<<"true motif instance num "<<true_instance_num<<endl;
	cout<<"counting corrent num: "<<corrent_num<<endl;
	cout<<"counting wrong num "<<wrong_num<<endl;
	cout<<"rate "<<corrent_rate<<endl;
}

void SamSelect::GenSubString(int occ)
{
	
	int occx = occ;
	int temp = m_l / 2;
	for (int i = 0; i < alllmer_1mismatch_count.size(); ++i)
	{
		for (int j = 0; j < alllmer_1mismatch_count[i].size(); ++j)
		{
			int num = 0;
			int max_occ = 0;
			int ol = 0;
			while(alllmer_1mismatch_count[i][j] <= occx)
			{
				if (j < alllmer_1mismatch_count[i].size())
				{
					j++;
				}
				else
					break;		
			}

			if (j >= alllmer_1mismatch_count[i].size())
			{
				break;
			}

			while (alllmer_1mismatch_count[i][j] > occx || ol <= 6)
			{
				if (alllmer_1mismatch_count[i][j] <= occx)
				{
					num++;
					j++;
					ol++;
				}
				if (j < alllmer_1mismatch_count[i].size() && ol <= 6)
				{
					num++;
					j++;
				}
				else
				{
					if (ol > 6)
					{
						j = j - ol;
						num = num - ol;
					}
					if (j >= alllmer_1mismatch_count[i].size())
					{
						j = j - (j - (alllmer_1mismatch_count[i].size() - 1));
						num = num - (j - (alllmer_1mismatch_count[i].size() - 1));
					}
					break;
				}

				if (alllmer_1mismatch_count[i][j] > max_occ)
				{
					max_occ = alllmer_1mismatch_count[i][j];
				}
			}
			if (num > 0)
			{
				ssc.row = i;
				ssc.ham_to_center = 0;
				ssc.occ = max_occ;

				for (int l = 0; l < 12 + num - 1; ++l)
				{
					ssc.subStr += filestring[i][j - num + l];
				}

				if (ssc.subStr.size() >= m_l)
				{
					vssc.push_back(ssc);
					ssc.subStr.clear();
				}
				else
				{

					if ((j - num < temp) || (j + 12 - 1 + temp > filestring[i].size() - 2))
					{
						if (j - num < temp)
						{
							for (int k = 0; k < j - num; ++k)
							{
								ssc.subStr = filestring[i][j - num - 1 - k] + ssc.subStr;
							}
							for (int k = 0; k < temp + temp - (j - num + 1); ++k)
							{
								ssc.subStr = ssc.subStr + filestring[i][j + 12 - 1 + k];
							}
						}

						if (j + 12 - 1 + temp > filestring[i].size() - 2)
						{
							for (int k = 0; k < (filestring[i].size() - 2) - (j + 12 - 1) + 1; ++k)
							{
								ssc.subStr = ssc.subStr + filestring[i][j + 12 - 1 + k];
							}
							for (int k = 0; k < temp + temp - ((filestring[i].size() - 2) - (j + 12 - 1) + 1); ++k)
							{
								ssc.subStr = filestring[i][j - num - 1 - k] + ssc.subStr;
							}
						}
					}
					else
					{
						for (int k = 0; k < temp; ++k)
						{
							ssc.subStr = filestring[i][j - num -1 - k] + ssc.subStr;
							ssc.subStr = ssc.subStr + filestring[i][j + 12 - 1 + k];
						}
					}

					vssc.push_back(ssc);
					ssc.subStr.clear();
				}
			}
			
		}
	}
}

float SamSelect::OccRx()
{
	float pk = 0, result;

	for (int i = 0; i <= 1; ++i)
	 {
	 	float temp;
	 	temp = (Combine(12, i) * pow(3, i))/ pow(4, 12);
	 	pk += temp;
	 }

	 return m_t * (m_n - 12 + 1) * pk;
}

int SamSelect::Combine(int x, int y)
{
	int result = 1;
	for (int i = 0; i < y; ++i)
	{
		result = result * (x - i);
	}
	for (int i = 0; i < y; ++i)
	{
		result = result / (y - i);
	}

	return result;
}

float SamSelect::OccMx()
{
	float pk = 0.01;
	m_qpercent = ((float)m_q) / 100;
	float result = m_t * m_qpercent * pk;

	return result;
}