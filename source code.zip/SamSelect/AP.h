#include "stdafx.h"
#include <memory.h>
#include <vector>
#include <string>
class GetData
{
public:
	void Input(vector<subStrContext> str);
	int DataNum;
	int Dimension;
	double *s;
	vector<subStrContext> DataSet;
	void GetS();	
	double p;
	int m_l;
	int m_d;
	double GetP();
	double ComputeSim(string a, string b);
	int get_charlen(char* a);
};
struct exemplar
{
	int num;
	bool count_flag;
	int count;
};
class AP_Cluster :public GetData
{
public:
	AP_Cluster(vector<subStrContext> str, double rd, int l, int d);
	int MaxIter;
	double *r;
	double *a;
	exemplar *exe;
	double *first_max;
	double *second_max;
	int *first_max_k1;
	double *add_max;
	double x;
	void Initial();
	void Get_max();
	void Get_add_max();
	void UpdateR_A();
	void Update_R();
	void Update_A();
	void Display();
	vector<vector<subStrContext> > CutClusterSet(vector<int> &center);
};