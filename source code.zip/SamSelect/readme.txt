Usage: ./my_sam [input file] [options]
Solver for sample sequence selection from large DNA datasets for quorum planted motif search
    -h: show this message.

  
[input file] the original data file

-l l: motif length
  
-d d: maximum number of mismatches between a motif and its instance
  
-q q: proportion of the input sequences containing motif instances

-T T: maximum number of sequences per sample sequence set (default 100)